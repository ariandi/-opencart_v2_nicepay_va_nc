<?php
// Text
$_['text_title'] = 'CVS (NICEPay)';
?>
